package bdd;

public class config {

    public static final int WAITTIME_INSTANT = 500;
    public static final int WAITTIME_TOO_SMALL = 2;
    public static final int WAITTIME_SMALL = 3;
    public static final int WAITTIME_ELEMENTOCCURENCE = 10;
    public static final int WAITTIME_MEDIUM = 5;
    public static final int WAITTIME_TIMEOUT = 60;
    public static final int WAITTIME_LONG_TIMEOUT = 90;
    public static final int WAITTIME_TOO_LONG_TIMEOUT = 120;
    public static final String USER_EMAIL="deneme_user@gmail.com";
}
