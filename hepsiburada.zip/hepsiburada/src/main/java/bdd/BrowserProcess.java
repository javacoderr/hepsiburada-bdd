package bdd;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import stepdefinition.Hooks;

public class BrowserProcess {

    WebDriver driver;
    public BrowserProcess() {
        driver = Hooks.driver;
    }

    public void mouseOver(By element){
        Actions action = new Actions(driver);
        action.moveToElement(driver.findElement(element)).build().perform();
    }
}
