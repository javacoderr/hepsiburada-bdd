package page;

import bdd.BrowserProcess;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import stepdefinition.Hooks;

public class SummerDressesPage extends BrowserProcess {
    WebDriver driver;

    public SummerDressesPage() {
        driver = Hooks.driver;
    }

    public static final By FIRST_PRODUCT = By.xpath("//*[@id='center_column']/ul/li[1]/div/div[1]/div");
    public static final By ADD_TO_CART_BUTTON = By.xpath("//*[@id='center_column']/ul/li[1]//*[contains(text(),'Add to cart')]");


    public void addToBasketProduct() {
        mouseOver(FIRST_PRODUCT);
        driver.findElement(ADD_TO_CART_BUTTON).click();
    }
}
