package page;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import stepdefinition.Hooks;


public class SigninPage {
    WebDriver driver;
    public static final By EMAIL_TEXTBOX = By.id("email_create");
    public static final By CREATE_BUTTON = By.id("SubmitCreate");
    public static final By MALE_GENDER_RADIO_BUTTON = By.id("id_gender1");
    public static final By FIRST_NAME_TEXTBOX = By.id("customer_firstname");
    public static final By LAST_NAME_TEXTBOX = By.id("customer_lastname");
    public static final By PASSWORD_TEXTBOX = By.id("passwd");
    public static final By ADDRESS_FIRSTNAME_TEXTBOX = By.id("firstname");
    public static final By ADDRESS_LASTNAME_TEXTBOX = By.id("lastname");
    public static final By COMPANY_TEXTBOX = By.id("company");
    public static final By ADDRESS_TEXTBOX = By.id("address1");
    public static final By CITY_TEXTBOX = By.id("city");
    public static final By STATE_COMBOBOX = By.id("id_state");
    public static final By ARIZONA_STATE = By.xpath("//*[@id='id_state']//*[contains(text(),'Arizona')]");
    public static final By POSTALCODE_TEXTBOX = By.id("postcode");
    public static final By MOBILE_PHONE_TEXTBOX = By.id("phone_mobile");
    public static final By ALIAS_TEXTBOX = By.id("alias");
    public static final By REGISTER_BUTTON = By.id("submitAccount");

    public SigninPage() {
        driver = Hooks.driver;
    }


    public void openSigninPage() {
        driver.navigate().to("http://automationpractice.com/index.php?controller=authentication&back=my-account");

    }

    public void makeSignin(String email) {
        driver.findElement(EMAIL_TEXTBOX).sendKeys(email);
        driver.findElement(CREATE_BUTTON).click();
    }

    public void fillUserFormAtSigninPage() {
        driver.findElement(MALE_GENDER_RADIO_BUTTON).click();
        driver.findElement(FIRST_NAME_TEXTBOX).click();
        driver.findElement(FIRST_NAME_TEXTBOX).sendKeys("kerim");
        driver.findElement(LAST_NAME_TEXTBOX).click();
        driver.findElement(LAST_NAME_TEXTBOX).sendKeys("aydın");
        driver.findElement(PASSWORD_TEXTBOX).click();
        driver.findElement(PASSWORD_TEXTBOX).sendKeys(RandomStringUtils.randomAlphabetic(5));
    }

    public void fillUserAddressInfo() {
        driver.findElement(ADDRESS_FIRSTNAME_TEXTBOX).click();
        driver.findElement(ADDRESS_FIRSTNAME_TEXTBOX).sendKeys("kerim");
        driver.findElement(ADDRESS_LASTNAME_TEXTBOX).click();
        driver.findElement(ADDRESS_LASTNAME_TEXTBOX).sendKeys("aydin");
        driver.findElement(ADDRESS_TEXTBOX).click();
        driver.findElement(ADDRESS_TEXTBOX).sendKeys("myaddress mycity mydistrict");
        driver.findElement(CITY_TEXTBOX).click();
        driver.findElement(CITY_TEXTBOX).sendKeys("Phoenix");
        driver.findElement(STATE_COMBOBOX).click();
        driver.findElement(ARIZONA_STATE).click();
        driver.findElement(POSTALCODE_TEXTBOX).click();
        driver.findElement(POSTALCODE_TEXTBOX).sendKeys("11111");
        driver.findElement(MOBILE_PHONE_TEXTBOX).click();
        driver.findElement(MOBILE_PHONE_TEXTBOX).sendKeys("11111123");
        driver.findElement(REGISTER_BUTTON).click();
    }

}
