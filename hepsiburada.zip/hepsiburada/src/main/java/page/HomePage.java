package page;

import bdd.BrowserProcess;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import stepdefinition.Hooks;

public class HomePage extends BrowserProcess {
    WebDriver driver;

    public HomePage() {
        driver = Hooks.driver;
    }

    public static final By DRESSES_LABEL = By.xpath("//*[@id='block_top_menu']/ul/li[2]/a");
    public static final By SUMMER_DRESSES_LABEL = By.xpath("//*[@id='block_top_menu']/ul/li[2]/ul/li[3]/a");


    public void clickSummerDressesCategory() {
        mouseOver(DRESSES_LABEL);
        driver.findElement(SUMMER_DRESSES_LABEL).click();
    }
}
