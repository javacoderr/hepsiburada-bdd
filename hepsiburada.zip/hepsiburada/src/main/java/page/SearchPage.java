package page;

import bdd.BrowserProcess;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import stepdefinition.Hooks;

public class SearchPage extends BrowserProcess {
    WebDriver driver;

    public SearchPage() {
        driver = Hooks.driver;
    }

    public static final By SEARCH_TEXTBOX = By.id("search_query_top");
    public static final By SEARCH_BUTTON = By.xpath("//*[contains(@name,'submit_search')]");
    public static final By FIRST_PRODUCT_AREA = By.xpath("//*[@id='best-sellers_block_right']/div/ul/li[1]");
    public static final By FIRST_PRODUCT = By.xpath("//*[@id='center_column']/ul/li[1]/div/div[1]/div");
    public static final By ADD_TO_CART_BUTTON = By.xpath("//*[@id='center_column']/ul/li[1]//*[contains(text(),'Add to cart')]");
    public static final By CART_ITEM_LABEL = By.xpath("//*[contains(@title,'View my shopping cart')]");
    public static final By GO_CHECKOUT_BUTTON = By.xpath("//*[contains(@title,'Check out')]");
    public static final By PROCEED_TO_CHECKOUT_BUTTON = By.xpath("//*[@title='Proceed to checkout']");


    public void searchWithKeywords(String keyword) {
        driver.findElement(SEARCH_TEXTBOX).click();
        driver.findElement(SEARCH_TEXTBOX).sendKeys(keyword);
        driver.findElement(SEARCH_BUTTON).click();
    }

    public void addToBasket() {
        mouseOver(FIRST_PRODUCT);
        driver.findElement(ADD_TO_CART_BUTTON).click();
    }


    public void goCheckOutPage() {
        mouseOver(CART_ITEM_LABEL);
        driver.findElement(GO_CHECKOUT_BUTTON);
        driver.findElement(PROCEED_TO_CHECKOUT_BUTTON).click();
    }
}
