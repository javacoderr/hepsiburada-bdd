package page;

import bdd.BrowserProcess;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import stepdefinition.Hooks;

public class ProductDetailPage extends BrowserProcess {
    WebDriver driver;

    public ProductDetailPage() {
        driver = Hooks.driver;
    }

    public static final By ADD_TO_BASKET_BUTTON = By.id("add_to_cart");
    public static final By PROCEED_TO_CHECKOUT_BUTTON = By.xpath("//*[@title='Proceed to checkout']");


}
