package stepdefinition;

import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;
import page.HomePage;
import page.SummerDressesPage;

public class HomePageStepDefinition {

    WebDriver driver;

    HomePage homePage = new HomePage();
    SummerDressesPage summerDressesPage = new SummerDressesPage();

    public HomePageStepDefinition() {
        driver = Hooks.driver;
    }


    @And("^User add to basket summer dresses product$")
    public void userAddToBasketSummerDressesProduct() {
        homePage.clickSummerDressesCategory();
        summerDressesPage.addToBasketProduct();
    }
}
