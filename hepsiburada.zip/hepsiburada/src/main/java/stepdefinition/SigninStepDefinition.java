package stepdefinition;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import org.apache.commons.lang.RandomStringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import page.HomePage;
import page.SigninPage;

public class SigninStepDefinition {

    WebDriver driver;

    public SigninStepDefinition() {
        driver = Hooks.driver;
    }

    SigninPage signinPage = new SigninPage();


    @Given("^User make sign in$")
    public void userSignin() {
        signinPage.openSigninPage();
        signinPage.makeSignin(RandomStringUtils.randomAlphabetic(5) + "@gmaill.com");
        signinPage.fillUserFormAtSigninPage();
        signinPage.fillUserAddressInfo();
        Assert.assertTrue("User didn't sign in" , driver.findElement(By.xpath("//*[@class='logout']")).isDisplayed());
    }
}
