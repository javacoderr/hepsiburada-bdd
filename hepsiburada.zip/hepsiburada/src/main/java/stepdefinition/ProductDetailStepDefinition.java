package stepdefinition;

import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;
import page.ProductDetailPage;
import page.SearchPage;

public class ProductDetailStepDefinition {

    WebDriver driver;

    public ProductDetailStepDefinition() {
        driver = Hooks.driver;
    }

    ProductDetailPage productDetailPage = new ProductDetailPage();

}
