package stepdefinition;

import cucumber.api.java.en.And;
import org.openqa.selenium.WebDriver;
import page.ProductDetailPage;
import page.SearchPage;

public class SearchStepDefinition {

    WebDriver driver;

    public SearchStepDefinition() {
        driver = Hooks.driver;
    }

    SearchPage searchPage = new SearchPage();


    @And("^User searches with summer keyword$")
    public void userSearchesWithSummerKeyword() {
        searchPage.searchWithKeywords("Summer");
    }

    @And("^User add to basket summer search result$")
    public void userAddToBasketSummerSearchResult() throws InterruptedException {
        searchPage.addToBasket();
        searchPage.goCheckOutPage();
    }
}
